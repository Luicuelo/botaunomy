package thaumcraft.common.tiles;
import net.minecraft.client.renderer.texture.ITickable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.aspects.IAspectContainer;
import thaumcraft.api.casters.IInteractWithCaster;
import thaumcraft.api.items.IGogglesDisplayExtended;



public class TileInfusionMatrix extends TileThaumcraft implements IInteractWithCaster, IAspectContainer, ITickable, IGogglesDisplayExtended
{

		public final boolean crafting = false;

		@Override
		public String[] getIGogglesText() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void tick() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public AspectList getAspects() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void setAspects(AspectList aspects) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public boolean doesContainerAccept(Aspect tag) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public int addToContainer(Aspect tag, int amount) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public boolean takeFromContainer(Aspect tag, int amount) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean takeFromContainer(AspectList ot) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean doesContainerContainAmount(Aspect tag, int amount) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean doesContainerContain(AspectList ot) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public int containerContains(Aspect tag) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public boolean onCasterRightClick(World world, ItemStack casterStack, EntityPlayer player, BlockPos pos,
				EnumFacing side, EnumHand hand) {
			// TODO Auto-generated method stub
			return false;
		}
}
