package thaumcraft.common.tiles;
import net.minecraft.tileentity.TileEntity;

public class TileThaumcraft extends TileEntity
{
	
}